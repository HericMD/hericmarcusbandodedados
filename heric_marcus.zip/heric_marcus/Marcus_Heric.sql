-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipo_usuario (
cod_tipuser int PRIMARY KEY,
desc_tipuser varchar(250) default
)

CREATE TABLE midia (
titulo_midia varchar(100) not null,
caminho_midia varchar(250) default,
cod_midia int unique not null PRIMARY KEY,
cod_postagem int unique not null
)

CREATE TABLE ong (
email_ong varchar(250) unique not null,
telefone_ong varchar(14) not null,
nome_ong varchar(100) default,
cod_ong int unique not null PRIMARY KEY
)

CREATE TABLE usuario (
idade int not null,
nome varchar(250) not null,
email varchar(250) unique not null,
cod_usuario int unique not null PRIMARY KEY,
telefone varchar(14) not null,
cod_tipuser int default,
FOREIGN KEY(cod_tipuser) REFERENCES tipo_usuario (cod_tipuser)
)

CREATE TABLE postagem (
titulo_postagem varchar(100) not null,
categoria varchar(100) default,
cod_postagem int unique not null PRIMARY KEY,
texto_postagem varchar(1000) default,
cod_usuario int unique not null,
cod_ong int unique not null,
FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario),
FOREIGN KEY(cod_ong) REFERENCES ong (cod_ong)
)

CREATE TABLE comenta (
cod_postagem int unique not null,
cod_usuario int unique not null,
dathora_coment timestamp auto_increment,
texto_coment varchar(250) default,
FOREIGN KEY(cod_postagem) REFERENCES postagem (cod_postagem),
FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario)
)

CREATE TABLE curtir (
cod_postagem int unique not null,
cod_usuario int unique not null,
dathora_curtir timestamp auto_increment,
FOREIGN KEY(cod_postagem) REFERENCES postagem (cod_postagem),
FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario)
)

CREATE TABLE doacao (
cod_ong int,
cod_usuario int,
dt_doacao date,
valor_doacao decimal(10,2),
FOREIGN KEY(cod_ong) REFERENCES ong (cod_ong),
FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario)
)

CREATE TABLE voluntario (
cod_ong int unique not null,
cod_usuario int unique not null,
dt_voluntario date default,
FOREIGN KEY(cod_ong) REFERENCES ong (cod_ong),
FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario)
)

ALTER TABLE midia ADD FOREIGN KEY(cod_postagem) REFERENCES postagem (cod_postagem)
