-- Gera��o de Modelo f�sico
-- Sql ANSI 2003 - brModelo.



CREATE TABLE tipo_usuario (
desc_tipuser varchar(250),
cod_tipuser int NOT NULL AUTO_INCREMENT,
 PRIMARY KEY (cod_tipuser)
);

CREATE TABLE midia (
titulo_midia varchar(100) not null,
caminho_midia varchar(50) not null,
cod_midia int not null,
cod_postagem int not null,
PRIMARY KEY (cod_midia)
);

CREATE TABLE ong (
email_ong varchar(100) not null UNIQUE,
telefone_ong varchar(14) int not null,
nome_ong varchar(100) default,
cod_ong int not null,
PRIMARY KEY (cod_ong)
);

CREATE TABLE postagem (
titulo_postagem varchar(100) not null,
categoria varchar(100) default,
cod_postagem int not null PRIMARY KEY AUTO_INCREMENT,
texto_postagem varchar(1000) default,
cod_usuario int unique not null,
cod_ong int unique not null,
FOREIGN KEY(cod_ong) REFERENCES ong (cod_ong)
);

CREATE TABLE voluntario (
cod_ong int unique not null,
cod_usuario int unique not null,
dt_voluntario date default,
FOREIGN KEY(cod_ong) REFERENCES ong (cod_ong)
);

CREATE TABLE doacao (
cod_ong int unique not null,
cod_usuario int unique not null,
dt_doacao date default,
valor_doacao decimal(10,2) default,
FOREIGN KEY(cod_ong) REFERENCES ong (cod_ong)
);

CREATE TABLE comenta (
cod_postagem int unique not null,
cod_usuario int unique not null,
dathora_coment timestamp auto_increment,
texto_coment varchar(250) default,
FOREIGN KEY(cod_postagem) REFERENCES postagem (cod_postagem)
);

CREATE TABLE curtir (
cod_postagem int unique not null,
cod_usuario int unique not null,
dathora_curtir timestamp auto_increment,
FOREIGN KEY(cod_postagem) REFERENCES postagem (cod_postagem)
);

CREATE TABLE usuario (
idade int not null,
nome varchar(250) not null,
email varchar(250) unique not null,
cod_usuario int not null PRIMARY KEY,
telefone varchar(14) not null,
cod_tipuser int default,
FOREIGN KEY(cod_tipuser) REFERENCES tipo_usuario (cod_tipuser)
);

ALTER TABLE midia ADD FOREIGN KEY(cod_postagem) REFERENCES postagem (cod_postagem);
ALTER TABLE postagem ADD FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario);
ALTER TABLE voluntario ADD FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario);
ALTER TABLE doacao ADD FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario);
ALTER TABLE comenta ADD FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario);
ALTER TABLE curtir ADD FOREIGN KEY(cod_usuario) REFERENCES usuario (cod_usuario);

--CREATE TABLE `clientes` (
  --`cod_cliente` int NOT NULL AUTO_INCREMENT,
  --`nome` varchar(150) NOT NULL,
  --`email` varchar(180) NOT NULL,
  --`login` varchar(80) NOT NULL,
  --`senha` varchar(20) NOT NULL,
  --`endereco_cobranca` varchar(300) NOT NULL,
  --PRIMARY KEY (`cod_cliente`),
  --UNIQUE KEY `email` (`email`),
  --UNIQUE KEY `login` (`login`)
--) ;

--CREATE TABLE tipo_usuario (
--desc_tipuser varchar(250),
--cod_tipuser int NOT NULL AUTO_INCREMENT,
-- PRIMARY KEY (cod_tipuser)
--);

